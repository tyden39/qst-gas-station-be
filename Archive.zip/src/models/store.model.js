const sequelize = require("../dbs/init.database")
const { Model, DataTypes } = require("sequelize")
const Branch = require("./branch.model")

class Store extends Model {}

Store.init(
  {
    id: {
      type: DataTypes.STRING,
      allowNull: false,
      primaryKey: true,
      unique: true
    },
    name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    address: {
      type: DataTypes.STRING,
    },
    email: {
      type: DataTypes.STRING,
      unique: true,
      validate: {
        isEmail: true
      }
    },
    phone: {
      type: DataTypes.STRING,
      unique: true,
    },
  },
  {
    sequelize,
    modelName: "Store",
    tableName: "stores",
    timestamps: true,
  }
)

Store.belongsTo(Branch)
Branch.hasMany(Store)

module.exports = Store
