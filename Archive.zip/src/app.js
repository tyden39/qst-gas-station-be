require("dotenv").config()
const moment = require("moment")
const compression = require("compression")
const express = require("express")
const { default: helmet } = require("helmet")
// const morgan = require("morgan")
const sequelize = require("./dbs/init.database")
const Company = require("./models/company.model")
const Branch = require("./models/branch.model")
const User = require("./models/user.model")
const Invoice = require("./models/invoice.model")
const cors = require('cors')
const app = express()

// middlewares
// app.use(morgan('dev'))
app.use(helmet())
app.use(compression())
app.use(express.json())
app.use(express.urlencoded({ extended: true }))

const corsOptions = {
  origin: 'http://localhost:3000',
  methods: 'GET,HEAD,PUT,PATCH,POST,DELETE',
  credentials: true, // Enable CORS for cookies, authorization headers, etc.
  optionsSuccessStatus: 204 // Some legacy browsers choke on 204
};

app.use(cors(corsOptions));

// db
sequelize
  .sync()
  .then(async () => {
    // console.log("Connection has been established successfully.")

    // const companyA = await Company.create({ name: 'Company A' });
    // const companyB = await Company.create({ name: 'Company B' });

    // const branch1 = await Branch.create({ name: 'Branch 1', companyId: companyA.id });
    // const branch2 = await Branch.create({ name: 'Branch 2', companyId: companyA.id });
    // const branch3 = await Branch.create({ name: 'Branch 3', companyId: companyB.id });

    // await User.create({ username: 'admin', password: '$2b$10$9ehv26dwrM3Yms7wpPqvOOiAyiiaBrhQ1hkn8DPiukB5FBAt7CcfK' });
    // await User.create({ username: 'User 1', password: '123', branchId: branch1.id, companyId: companyA.id });
    // await User.create({ username: 'User 2', password: '123', branchId: branch2.id, companyId: companyA.id });
    // await User.create({ username: 'User 3', password: '123', branchId: branch3.id, companyId: companyB.id });
    // await User.create({ username: 'User 4', password: '123', branchId: null, companyId: companyA.id });

    // const invoice = {
    //   "Logger_ID": "01905969501",
    //   "Check_Key": "T00R00K155528140524",
    //   "Logger_Time": "14-05-2024 15-55-28",
    //   "Pump_ID": 0,
    //   "Bill_No": 23,
    //   "Bill_Type": 1,
    //   "Fuel_Type": "XĂNG RON 95 - III",
    //   "Start_Time": "12-04-2024 16-51-21",
    //   "End_Time": "12-04-2024 16-52-50",
    //   "Unit_Price": 25740,
    //   "Quantity": 0.545,
    //   "Total_Price": 14020
    // }
    // const loggerTimeDate = moment(
    //   invoice.Logger_Time,
    //   "DD-MM-YYYY HH:mm:ss"
    // ).toDate()
    // const startTimeDate = moment(
    //   invoice.Start_Time,
    //   "DD-MM-YYYY HH:mm:ss"
    // ).toDate()
    // const endTimeDate = moment(invoice.End_Time, "DD-MM-YYYY HH:mm:ss").toDate()
    // const createdInvoice = await Invoice.create({
    //   ...invoice,
    //   Logger_Time: loggerTimeDate,
    //   Start_Time: startTimeDate,
    //   End_Time: endTimeDate,
    // })

    // console.log("Data inserted!");
    // const users = await User.findAll({
    //   include: [Branch, Company]
    // })
    // console.log(users.map(user => user.toJSON()))
  })
  .catch((error) => console.error("Unable to connect to the database:", error))

// routes
app.use("/", require("./routes"))

// handling error
app.use((req, res, next) => {
  const error = Error("Not Found")
  error.status = 404
  next(error)
})

app.use((error, req, res, next) => {
  const statusCode = error.status || 500
  return res.status(statusCode).json({
    status: statusCode,
    message: error.message || "Internal Server Error",
  })
})

module.exports = app
