const moment = require("moment")
const Invoice = require("../models/invoice.model")
const { BadRequestError } = require("../core/error.response")

class InvoiceService {
  static async createInvoice(data) {
    const loggerTimeDate = moment(
      data.Logger_Time,
      "DD-MM-YYYY HH:mm:ss"
    ).toDate()
    const startTimeDate = moment(
      data.Start_Time,
      "DD-MM-YYYY HH:mm:ss"
    ).toDate()
    const endTimeDate = moment(data.End_Time, "DD-MM-YYYY HH:mm:ss").toDate()
    const createdInvoice = await Invoice.create({
      ...data,
      Logger_Time: loggerTimeDate,
      Start_Time: startTimeDate,
      End_Time: endTimeDate,
    })
    return createdInvoice
  }

  static async getInvoiceById(params) {
    const { id, storeId } = params
    const invoice = await Invoice.findOne({
      where: { Bill_No: id, Logger_ID: storeId },
    })
    if (!invoice) throw new BadRequestError(`Invoice ID ${id} not found!`)
    return invoice
  }

  static async getInvoices({ keyword, billType, fuelType, pumpId, startDate, endDate, pageSize = 10, page = 1}) {

    const offset = (page - 1) * pageSize

    const dateFilter = startDate && endDate ? {
      createdAt: {
        [Op.between]: [new Date(startDate), new Date(endDate)]
      }
    } : {};
  
    const keywordFilter = keyword ? {
      [Op.or]: [
        { Logger_ID: { [Op.like]: `%${keyword}%` } },
        { Check_Key: { [Op.like]: `%${keyword}%` } },
      ]
    } : {};

    const billTypeFilter = billType > 0 && billType <= 5 ? {
      Bill_Type: billType
    } : {};

    const fuelTypeFilter = fuelType ? {
      Fuel_Type: fuelType
    } : {};
    const pumpIdFilter = pumpId >= 0 && pumpId < 16 ? {
      Pump_ID: pumpId
    } : {};
  
    // Combine filters
    const where = {
      ...dateFilter,
      ...keywordFilter,
      ...billTypeFilter,
      ...fuelTypeFilter,
      ...pumpIdFilter,
    };

    if (startDate && endDate)
      where.createdAt = {
        [Op.between]: [new Date(startDate), new Date(endDate)],
      }

    const { count, rows: invoices } = await Invoice.findAndCountAll({
      where,
      limit: pageSize,
      offset: offset,
      order: [['createdAt', 'DESC']]
    })

    const totalPages = Math.ceil(count / pageSize);

    return {
      data: invoices,
      meta: {
        totalItems: count,
        totalPages,
        currentPage: page,
        pageSize
      }
    }
  }

  static async updateInvoice(id, data) {
    const invoice = await Invoice.findByPk(id)
    if (!invoice) {
      throw new Error("Invoice not found")
    }
    return await Invoice.update(data)
  }

  static async deleteInvoice(id) {
    const Invoice = await Invoice.findByPk(id)
    if (!Invoice) {
      throw new Error("Invoice not found")
    }
    return await Invoice.destroy()
  }
}

module.exports = InvoiceService
