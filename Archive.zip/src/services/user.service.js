const { Op } = require("sequelize")
const User = require("../models/user.model")

class UserService {
  static findByUsername = async ({ username }) => {
    return await User.findOne({
      where: {
        username,
      },
    })
  }

  static async createUser(data) {
    return await User.create(data)
  }

  static async getUserById(id) {
    return await User.findByPk(id)
  }

  static async getUsers(filter) {
    const where = {}

    if (filter.name) {
      where.name = { [Op.like]: `%${filter.name}%` }
    }
    if (filter.email) {
      where.email = { [Op.like]: `%${filter.email}%` }
    }

    return await User.findAll({ where })
  }

  static async updateUser(id, data) {
    const user = await User.findByPk(id)
    if (!user) {
      throw new Error("User not found")
    }
    return await user.update(data)
  }

  static async deleteUser(id) {
    const user = await User.findByPk(id)
    if (!user) {
      throw new Error("User not found")
    }
    await User.destroy({ where: { id }, force: true })
  }

// static async users {
// return await User.findAll({
//   include: [
//       {
//           model: Branch,
//           attributes: ['branchName']
//       },
//       {
//           model: Company,
//           attributes: ['companyName']
//       }
//   ]
// })}
}

module.exports = UserService
