"use strict"

const JWT = require("jsonwebtoken")
const crypto = require("crypto")
const KeyTokenService = require("../services/keyToken.service")
const {
  BadRequestError,
  NotFoundError,
  UnauthorizedError,
} = require("../core/error.response")
const asyncHandler = require("../helpers/asyncHandler")
const {
  app: { publicKey, privateKey },
} = require("../configs/config.server")

const HEADER = {
  CLIENT_ID: "x-client-id",
  AUTHORIZATION: "authorization",
}

const createTokenPair = async (payload) => {
  try {
    // JWT.sign is not async function why use await?
    const accessToken = await JWT.sign(payload, privateKey, {
      algorithm: "RS256",
    })

    const refreshToken = await JWT.sign(payload, privateKey, {
      algorithm: "RS256",
    })

    JWT.verify(accessToken, publicKey, (err, decode) => {
      if (err) {
        console.error(`JWT verify error::`, err)
      } else {
        // console.log(`JWT verify::`, "success")
      }
    })

    return { accessToken, refreshToken }
  } catch (error) {
    console.log("createTokenPair error::", error.message)
  }
}

const createTokens = async ({ user }) => {
  const userId = user.id

  const tokens = await createTokenPair({ userId, username: user.username })

  const saveTokens = await KeyTokenService.createKeyToken({
    accessToken: tokens.accessToken,
    refreshToken: tokens.refreshToken,
    userId,
  })

  return saveTokens
}

const authentication = asyncHandler(async (req, res, next) => {
  try {
    const accessToken = req.headers[HEADER.AUTHORIZATION]
    if (!accessToken) throw new UnauthorizedError("Invalid token")

    const decodeUser = JWT.verify(accessToken, publicKey, { algorithms: ['RS256'] })

    const keyStore = await KeyTokenService.findByPropertyName(
      "user",
      decodeUser.userId
    )
    if (!keyStore) throw new NotFoundError("Invalid token")

    req.keyStore = keyStore
    return next()
  } catch (error) {
    throw error
  }
})

const verifyJWT = (token, keySecret) => {
  return JWT.verify(token, keySecret)
}

module.exports = {
  createTokenPair,
  createTokens,
  authentication,
  verifyJWT,
}
