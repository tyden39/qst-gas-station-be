module.exports = {
  StatusCodes: require('./statusCode'),
  ReasonPhrases: require('./reasonPhrase')
}